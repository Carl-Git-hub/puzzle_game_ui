const state = {
    numRows: 18,
    numCols: 10
  }
  
  const mutations = {
  }
  
  const actions = {
  }

  const getters = {
    getNumRows: state => state.numRows,
    getNumCols: state => state.numCols
  }
  
  export default {
    state,
    mutations,
    actions,
    getters
  }
  