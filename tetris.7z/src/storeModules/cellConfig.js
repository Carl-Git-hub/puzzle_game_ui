const state = {
    cellSize: 30
  }
  
  const mutations = {
  }
  
  const actions = {
  }

  const getters = {
    getCellSize: state => state.cellSize
  }
  
  export default {
    state,
    mutations,
    actions,
    getters
  }
  